







<div class="row">
  <div class=" col-md-12" style="padding-bottom:10px;">
  <h3>1st Semester</h3>
              
  <table class="table table-striped">
    <thead>
      <tr>
        <th>Select subject</th>
        <th>Subject code</th>
        <th>Subject name</th>
		<th>Credit</th>
      </tr>
    </thead>
    <tbody>
      <tr>
	    <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="EE21101{1}">
            </div>
		</td>
        <td>EE21101</td>
        <td>Power System Analysis and Operation</td>
        <td>4</td>
      </tr>
      <tr>
        <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="EE21102{1}">
            </div>
		</td>
		<td>EE21102</td>
        <td>Power Electronics</td>
        <td>4</td>
      </tr>
      <tr>
        <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="EE21103{1}">
            </div>
		</td>
		<td>EE21103</td>
        <td>Control Systems - I</td>
        <td>4</td>
      </tr>
	  <tr>
        <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="Elective-I">
            </div>
		</td>
		<td></td>
        <td>Elective I</td>
        <td>3</td>
      </tr>
	  <tr>
        <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="Elective-II">
            </div>
		</td>
		<td></td>
        <td>Elective-II</td>
        <td>3</td>
      </tr>
	  <tr>
        <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="EE21201{1}">
            </div>
		</td>
		<td>EE21201</td>
        <td>Power and Energy Systems Lab</td>
        <td>2</td>
      </tr>
	  <tr>
        <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="EE21202{1}">
            </div>
		</td>
		<td>EE21202</td>
        <td>Intelligent Control Systems Laboratory</td>
        <td>2</td>
      </tr>
    </tbody>
  </table>
</div>
</div><br>	