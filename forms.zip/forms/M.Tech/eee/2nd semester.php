







<div class="row">
  <div class=" col-md-12" style="padding-bottom:10px;">
  <h3>2nd Semester</h3>
              
  <table class="table table-striped">
    <thead>
      <tr>
        <th>Select subject</th>
        <th>Subject code</th>
        <th>Subject name</th>
		<th>Credit</th>
      </tr>
    </thead>
    <tbody>
      <tr>
	    <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="EE22101{2}">
            </div>
		</td>
        <td>EE22101</td>
        <td>Power System Stability and Control</td>
        <td>4</td>
      </tr>
      <tr>
        <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="EE22102{2}">
            </div>
		</td>
		<td>EE22102</td>
        <td>Electric Drive</td>
        <td>4</td>
      </tr>
      <tr>
        <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="EE22103{2}">
            </div>
    </td>
    <td>EE22103</td>
        <td>Control Systems - II</td>
        <td>4</td>
      </tr>      
      <tr>
        <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="Elective-III{2}">
            </div>
    </td>
    <td></td>
        <td>Elective-III</td>
        <td>3</td>
      </tr>      
      <tr>
        <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="Elective-IV{2}">
            </div>
		</td>
		<td></td>
        <td>Elective-IV</td>
        <td>3</td>
      </tr>
	  <tr>
        <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="EC22201{2}">
            </div>
		</td>
		<td>EE22201</td>
        <td>Power Electronics and Power Quality Laboratory</td>
        <td>2</td>
      </tr>
      <tr>
        <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="EE22202{2}">
            </div>
		</td>
		<td>EE22202</td>
        <td>Term Paper</td>
        <td>2</td>
      </tr>
    </tbody>
  </table>
</div>
</div><br>	
