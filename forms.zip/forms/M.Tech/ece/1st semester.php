







<div class="row">
  <div class=" col-md-12" style="padding-bottom:10px;">
  <h3>1st Semester</h3>
              
  <table class="table table-striped">
    <thead>
      <tr>
        <th>Select subject</th>
        <th>Subject code</th>
        <th>Subject name</th>
		<th>Credit</th>
      </tr>
    </thead>
    <tbody>
      <tr>
	    <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="EC21101{1}">
            </div>
		</td>
        <td>EC21101</td>
        <td>Introduction to VLSI Design</td>
        <td>3</td>
      </tr>
      <tr>
        <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="EC21102{1}">
            </div>
		</td>
		<td>EC21102</td>
        <td>Semiconductor Device Theory and Modelling</td>
        <td>3</td>
      </tr>
      <tr>
        <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="EC21103{1}">
            </div>
		</td>
		<td>EC21103</td>
        <td>VLSI Technology & Processing</td>
        <td>3</td>
      </tr>
	  <tr>
        <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="EC21104{1}">
            </div>
		</td>
		<td>EC21104</td>
        <td>Analog Integrated Circuit Design</td>
        <td>3</td>
      </tr>
	  <tr>
        <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="EC21105{1}">
            </div>
		</td>
		<td>EC21105</td>
        <td>Modelling of Digital System</td>
        <td>3</td>
      </tr>
	  <tr>
        <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="EC21201{1}">
            </div>
		</td>
		<td>EC21201</td>
        <td>Semiconductor device simulation and Process Modelling Lab</td>
        <td>2</td>
      </tr>
	  <tr>
        <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="EC21202{1}">
            </div>
		</td>
		<td>EC21202</td>
        <td>Modelling of digital system lab</td>
        <td>2</td>
      </tr>
    </tbody>
  </table>
</div>
</div><br>	