<div class="row">
  <div class=" col-md-12" style="padding-bottom:10px;">
  <h3>2nd Semester</h3>

  <table class="table table-striped">
    <thead>
      <tr>
        <th>Select subject</th>
        <th>Subject code</th>
        <th>Subject name</th>
		<th>Credit</th>
      </tr>
    </thead>
    <tbody>
      <tr>
	    <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="MA12101{2}">
            </div>
		</td>
        <td>MA12101</td>
        <td>Mathematics-II</td>
        <td>4</td>
      </tr>
      <tr>
        <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="CY12101{2}">
            </div>
		</td>
		<td>CY12101</td>
        <td>Physics</td>
        <td>3</td>
      </tr>
      <tr>
        <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="CY12201{2}">
            </div>
		</td>
		<td>CY12201</td>
        <td>Chemistry</td>
        <td>3</td>
      </tr>
	  <tr>
        <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="EE12101{2}">
            </div>
		</td>
		<td>EE12101</td>
        <td>Basic Electrical Science</td>
        <td>3</td>
      </tr>
	  <tr>
        <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="BT12101{2}">
            </div>
		</td>
		<td>BT12101</td>
        <td>Introduction to Life Science</td>
        <td>2</td>
      </tr>
	  <tr>
        <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="ZZ12202{2}">
            </div>
		</td>
		<td>ZZ12202</td>
        <td>Workshop Practice-II (EEE & ECE)</td>
        <td>2</td>
      </tr>
      <tr>
	    <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="ZZ12101{2}">
            </div>
		</td>
        <td>ZZ12101</td>
        <td>Enviromental Studies and Disaster Management</td>
        <td>4</td>
      </tr>
	  <tr>
        <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="ME12201{2}">
            </div>
		</td>
		<td>ME12201</td>
        <td>Engineering Graphics</td>
        <td>3</td>
      </tr>
    </tbody>
  </table>
</div>
</div><br>
