







<div class="row">
  <div class=" col-md-12" style="padding-bottom:10px;">
  <h3>2nd Semester</h3>

  <table class="table table-striped">
    <thead>
      <tr>
        <th>Select subject</th>
        <th>Subject code</th>
        <th>Subject name</th>
		<th>Credit</th>
      </tr>
    </thead>
    <tbody>
      <tr>
	    <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="MA11101{1}">
            </div>
		</td>
        <td>MA11101</td>
        <td>Mathematics-I</td>
        <td>4</td>
      </tr>
      <tr>
        <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="PH11101{1}">
            </div>
		</td>
		<td>PH11101</td>
        <td>Physics</td>
        <td>3</td>
      </tr>
      <tr>
        <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="CS11101{1}">
            </div>
		</td>
		<td>CS11101</td>
        <td>Computer Programming</td>
        <td>3</td>
      </tr>
	  <tr>
        <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="ME11101{1}">
            </div>
		</td>
		<td>ME11101</td>
        <td>Engineering Mechanics</td>
        <td>3</td>
      </tr>
	  <tr>
        <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="HS11101{1}">
            </div>
		</td>
		<td>HS11101</td>
        <td>English Language and Composition</td>
        <td>2</td>
      </tr>
	  <tr>
        <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="ZZ11203{1}">
            </div>
		</td>
		<td>ZZ11203</td>
        <td>Physical Education/ Sports/ NSS</td>
        <td>2</td>
      </tr>
    <tr>
          <td><div style="padding-left:30%;">
              <input type="checkbox" name="subject[]" value="PH11201{1}">
              </div>
    </td>
    <td>PH11201</td>
        <td>Physics Laboratory</td>
          <td>2</td>
      </tr>
      <tr>
            <td><div style="padding-left:30%;">
                <input type="checkbox" name="subject[]" value="CS11201{1}">
                </div>
      </td>
      <td>CS11201</td>
          <td>Computer Programming Laboratory</td>
            <td>2</td>
        </tr>
        <tr>
              <td><div style="padding-left:30%;">
                  <input type="checkbox" name="subject[]" value="ZZ11201{1}">
                  </div>
        </td>
        <td>ZZ11201</td>
            <td>Workshop Practice-I ( CE & ME)</td>
              <td>2</td>
          </tr>
	  <tr>
        <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="ZZ1092{1}">
            </div>
		</td>
		<td>HS11102</td>
        <td>Professional Ethics & Value Education</td>
        <td>1</td>
      </tr>
    </tbody>
  </table>
</div>
</div><br>
