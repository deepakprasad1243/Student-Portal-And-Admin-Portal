







<div class="row">
  <div class=" col-md-12" style="padding-bottom:10px;">
  <h3>2nd Semester</h3>
              
  <table class="table table-striped">
    <thead>
      <tr>
        <th>Select subject</th>
        <th>Subject code</th>
        <th>Subject name</th>
		<th>Credit</th>
      </tr>
    </thead>
    <tbody>
      <tr>
	    <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="CY22101{2}">
            </div>
		</td>
        <td>CY22101</td>
        <td>Organic Chemistry�II</td>
        <td>4</td>
      </tr>
      <tr>
        <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="CY22102{2}">
            </div>
		</td>
		<td>CY22102</td>
        <td>Inorganic Chemistry�II</td>
        <td>4</td>
      </tr>
      <tr>
        <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="CY22103{2}">
            </div>
		</td>
		<td>CY22103</td>
        <td>Physical Chemistry�II</td>
        <td>4</td>
      </tr>
	  <tr>
        <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="CY22104{2}">
            </div>
		</td>
		<td>CY22104</td>
        <td>Biochemistry�II</td>
        <td>4</td>
      </tr>
	  <tr>
        <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="CY22105{2}">
            </div>
		</td>
		<td>CY22105</td>
        <td>Spectroscopy-I</td>
        <td>4</td>
      </tr>
	  <tr>
        <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="CY22201{2}">
            </div>
		</td>
		<td>CY22201</td>
        <td>Organic Chemistry Laboratory�II</td>
        <td>3</td>
      </tr>
	  <tr>
        <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="CY22202{2}">
            </div>
		</td>
		<td>CY22202</td>
        <td>Inorganic Chemistry laboratory�II</td>
        <td>3</td>
      </tr>
    </tbody>
  </table>
</div>
</div><br>	