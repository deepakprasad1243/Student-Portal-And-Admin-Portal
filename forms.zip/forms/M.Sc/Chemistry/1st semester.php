







<div class="row">
  <div class=" col-md-12" style="padding-bottom:10px;">
  <h3>1st Semester</h3>
              
  <table class="table table-striped">
    <thead>
      <tr>
        <th>Select subject</th>
        <th>Subject code</th>
        <th>Subject name</th>
		<th>Credit</th>
      </tr>
    </thead>
    <tbody>
      <tr>
	    <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="CY21101{1}">
            </div>
		</td>
        <td>CY21101</td>
        <td>Organic Chemistry�I</td>
        <td>4</td>
      </tr>
      <tr>
        <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="CY21102{1}">
            </div>
		</td>
		<td>CY21102</td>
        <td>Inorganic Chemistry�I</td>
        <td>4</td>
      </tr>
      <tr>
        <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="CY21103{1}">
            </div>
		</td>
		<td>CY21103</td>
        <td>Physical Chemistry�I</td>
        <td>4</td>
      </tr>
	  <tr>
        <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="CY21104{1}">
            </div>
		</td>
		<td>CY21104</td>
        <td>Biochemistry�I</td>
        <td>3</td>
      </tr>
	  <tr>
        <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="CY21105{1}">
            </div>
		</td>
		<td>CY21105</td>
        <td>Mathematics for Chemists</td>
        <td>3</td>
      </tr>
	  <tr>
        <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="CY21201{1}">
            </div>
		</td>
		<td>CY21201</td>
        <td>Organic Chemistry Laboratory�I</td>
        <td>3</td>
      </tr>
	  <tr>
        <td><div style="padding-left:30%;">
            <input type="checkbox" name="subject[]" value="CY21202{1}">
            </div>
		</td>
		<td>CY21202</td>
        <td>Inorganic Chemistry laboratory�I</td>
        <td>3</td>
      </tr>
    </tbody>
  </table>
</div>
</div><br>	